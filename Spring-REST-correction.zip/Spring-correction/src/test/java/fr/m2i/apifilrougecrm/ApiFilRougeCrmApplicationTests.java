package fr.m2i.apifilrougecrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFilRougeCrmApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
