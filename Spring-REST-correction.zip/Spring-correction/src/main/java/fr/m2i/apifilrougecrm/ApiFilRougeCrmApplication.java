package fr.m2i.apifilrougecrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiFilRougeCrmApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiFilRougeCrmApplication.class, args);
    }

}
